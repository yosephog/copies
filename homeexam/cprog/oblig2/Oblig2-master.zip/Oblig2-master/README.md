# Oblig2

Filene

* 1router.dat
* 5router.dat
* 10router.dat
* 100router.dat

er testfiler du kan test oppgaven din med.

